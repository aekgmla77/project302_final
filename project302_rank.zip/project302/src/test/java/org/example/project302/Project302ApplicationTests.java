package org.example.project302;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project302ApplicationTests {

    @Test
    void contextLoads() {
    }

}
