package org.example.project302.redis.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.redis.core.ZSetOperations;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SearchRankResponseDto {
    private String pdName;

    // ZSetOperations.TypedTuple<Object>을 SearchRankResponseDto로 변환하는 메서드
    public static SearchRankResponseDto convertToResponseRankingDto(ZSetOperations.TypedTuple<Object> tuple) {
        return new SearchRankResponseDto((String) tuple.getValue());
    }
}
