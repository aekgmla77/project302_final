package org.example.project302.user.entity;

public enum SnsType {
    LOCAL, KAKAO, NAVER, GOOGLE
}
