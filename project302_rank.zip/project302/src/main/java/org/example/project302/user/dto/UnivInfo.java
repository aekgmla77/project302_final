package org.example.project302.user.dto;

import lombok.Data;

@Data
public class UnivInfo {
    private Long idUniv;
    private String nameUniv;
    private String emailUniv;
}
