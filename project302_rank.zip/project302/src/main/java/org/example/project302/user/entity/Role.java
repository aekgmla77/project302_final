package org.example.project302.user.entity;


public enum Role {
    USER, ADMIN
}
