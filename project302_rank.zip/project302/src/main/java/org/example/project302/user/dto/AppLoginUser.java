package org.example.project302.user.dto;

import lombok.Data;

@Data
public class AppLoginUser {
    private String localId;
    private String password;
}
