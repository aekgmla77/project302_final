package org.example.project302.notification.entity;

public enum NotificationType {
    KEY, SCHD, CHAT   // 키워드, 스케줄(일정)
}
