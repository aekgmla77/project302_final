package org.example.project302.product.repository;

public interface BaseEnum<T> {
    T getValue();
}
