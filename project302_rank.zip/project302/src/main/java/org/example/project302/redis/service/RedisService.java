package org.example.project302.redis.service;

import lombok.extern.slf4j.Slf4j;
import org.example.project302.redis.dto.SearchRankResponseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
public class RedisService {

    private static final String POPULAR_KEWORD_KEY = "popularKeywords";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    // 인기 검색어 리스트 1위~10위까지
    public List<SearchRankResponseDto> searchRankList() {
        ZSetOperations<String, Object> ZSetOperations = redisTemplate.opsForZSet();
        // score순으로 10개 보여줌
        Set<org.springframework.data.redis.core.ZSetOperations.TypedTuple<Object>> typedTuples = ZSetOperations.reverseRangeWithScores(POPULAR_KEWORD_KEY, 0, 9);
        System.out.println(typedTuples.stream().map(SearchRankResponseDto::convertToResponseRankingDto).collect(Collectors.toList()) + "엥");
        return typedTuples.stream().map(SearchRankResponseDto::convertToResponseRankingDto).collect(Collectors.toList());
    }

    // 검색어 증가
    public void incrementKeyword(String keword){
        ZSetOperations<String, Object> zSetOps = redisTemplate.opsForZSet();
        zSetOps.incrementScore(POPULAR_KEWORD_KEY, keword, 1);
        log.info("증가");
    }

    // 인기 검색어 조회
    public Set<Object> getPopularKeywords(int count){
        ZSetOperations<String, Object> zSetOps = redisTemplate.opsForZSet();
        return zSetOps.reverseRange(POPULAR_KEWORD_KEY, 0, count - 1);
    }
}
