package org.example.project302.deal.entity;

public enum ReviewType {
    SELL, BUY
}
