package org.example.project302.user.entity;

public enum KeywordType {
    ALL, USED, GROUP
}
