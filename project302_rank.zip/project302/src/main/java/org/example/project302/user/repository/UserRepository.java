package org.example.project302.user.repository;

import org.example.project302.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
  Optional<User> findByLocalId(String localId);

  User findByEmail(String email);

  Optional<User> findByToken(String refreshToken);

  // localID로 ID 확인
  boolean existsByLocalId(String localId);

  // nickname 중복 체크
  boolean existsByNickname(String nickname);

  // 실례합니다
  


}
